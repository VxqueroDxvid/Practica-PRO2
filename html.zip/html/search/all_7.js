var searchData=
[
  ['m_47',['m',['../classArea__procesos.html#a46e20406f11a32b22939e908839e61d0',1,'Area_procesos::m()'],['../classCluster.html#aabe94e5dcab8699611f3d1014fba8c71',1,'Cluster::m()']]],
  ['main_48',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['memlibre_49',['memlibre',['../classProcesador.html#aeb6a03bb5562c050ea01d2710e4a1456',1,'Procesador']]],
  ['memoria_50',['memoria',['../classProcesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador']]],
  ['modificar_5farbol_51',['modificar_arbol',['../classCluster.html#acbd511292299d4eca9795ce676d77ded',1,'Cluster']]],
  ['modificar_5fcapacidad_52',['modificar_capacidad',['../classProcesador.html#a97c566409ffff90881502b2bb3d10d5e',1,'Procesador']]],
  ['modificar_5fcluster_53',['modificar_cluster',['../classCluster.html#a5b3a62f68ef842513a40dcf1cc8c6d78',1,'Cluster']]]
];
