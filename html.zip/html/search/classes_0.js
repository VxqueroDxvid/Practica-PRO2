var searchData=
[
  ['area_5fprocesos_71',['Area_procesos',['../classArea__procesos.html',1,'']]]
];
