var searchData=
[
  ['main_122',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5farbol_123',['modificar_arbol',['../classCluster.html#acbd511292299d4eca9795ce676d77ded',1,'Cluster']]],
  ['modificar_5fcapacidad_124',['modificar_capacidad',['../classProcesador.html#a97c566409ffff90881502b2bb3d10d5e',1,'Procesador']]],
  ['modificar_5fcluster_125',['modificar_cluster',['../classCluster.html#a5b3a62f68ef842513a40dcf1cc8c6d78',1,'Cluster']]]
];
