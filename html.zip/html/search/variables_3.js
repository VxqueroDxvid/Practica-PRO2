var searchData=
[
  ['idproceso_137',['idproceso',['../classProceso.html#aff40a887143ff055d425e26960018600',1,'Proceso']]],
  ['ids_138',['ids',['../classPrioridad.html#a5be230a98b6add5bdbae2b8ae61315da',1,'Prioridad']]]
];
