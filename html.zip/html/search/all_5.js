var searchData=
[
  ['idproceso_35',['idproceso',['../classProceso.html#aff40a887143ff055d425e26960018600',1,'Proceso']]],
  ['ids_36',['ids',['../classPrioridad.html#a5be230a98b6add5bdbae2b8ae61315da',1,'Prioridad']]],
  ['imprimir_5farea_5fespera_37',['imprimir_area_espera',['../classArea__procesos.html#a7269a649f00e6750930a50af9fa1c119',1,'Area_procesos']]],
  ['imprimir_5festructura_5fcluster_38',['imprimir_estructura_cluster',['../classCluster.html#a285714ee7b0d682682fbb634d2170f04',1,'Cluster']]],
  ['imprimir_5fprioridad_39',['imprimir_prioridad',['../classArea__procesos.html#a413db14b3deb4fae909776c5ff876ed9',1,'Area_procesos::imprimir_prioridad()'],['../classPrioridad.html#a75b67cd4f4d12527e89ed0662cbfa6ad',1,'Prioridad::imprimir_prioridad()']]],
  ['imprimir_5fprocesador_40',['imprimir_procesador',['../classCluster.html#a6a511c4f5270e5894fd78701b9207f1c',1,'Cluster::imprimir_procesador()'],['../classProcesador.html#ad0c00caaab94b8fa561e3db6ea7f36f2',1,'Procesador::imprimir_procesador()']]],
  ['imprimir_5fprocesadores_5fcluster_41',['imprimir_procesadores_cluster',['../classCluster.html#a9436d5be8c89c3c09e69b2ccebc7cff0',1,'Cluster']]],
  ['imprimir_5fproceso_42',['imprimir_proceso',['../classProceso.html#ac1c20f0a1a60574b8e246ccb82b6d1e6',1,'Proceso']]]
];
