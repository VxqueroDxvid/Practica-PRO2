var searchData=
[
  ['alta_5fprioridad_87',['alta_prioridad',['../classArea__procesos.html#ac9928c2bd54282cdb3cbedabf801429d',1,'Area_procesos']]],
  ['alta_5fproceso_5fespera_88',['alta_proceso_espera',['../classArea__procesos.html#ae9dd255b0b9bf603c70eab5d15673b88',1,'Area_procesos::alta_proceso_espera()'],['../classPrioridad.html#a2cf901202d3a78c1f00d95bef914a944',1,'Prioridad::alta_proceso_espera()']]],
  ['alta_5fproceso_5fprocesador_89',['alta_proceso_procesador',['../classCluster.html#a59c03d8d01f291906af0298e2f5bd126',1,'Cluster::alta_proceso_procesador()'],['../classProcesador.html#a05e06de75cbbab0e625bb5aece3dde9d',1,'Procesador::alta_proceso_procesador()']]],
  ['area_5fprocesos_90',['Area_procesos',['../classArea__procesos.html#a51ba6c181ccd598d1046d8c7901d7239',1,'Area_procesos']]],
  ['avanzar_5ftiempo_91',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a91055a2cc9c3129051a762a9eb2a1f19',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#a4ec4913a4c1a66714b39ae7c079bae29',1,'Proceso::avanzar_tiempo()']]]
];
