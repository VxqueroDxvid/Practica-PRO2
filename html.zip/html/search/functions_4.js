var searchData=
[
  ['hay_5fhijos_112',['hay_hijos',['../classCluster.html#ac22fc21339a06494c2e3b5e2df0a3e15',1,'Cluster']]]
];
