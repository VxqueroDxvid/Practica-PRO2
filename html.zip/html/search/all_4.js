var searchData=
[
  ['hay_5fhijos_33',['hay_hijos',['../classCluster.html#ac22fc21339a06494c2e3b5e2df0a3e15',1,'Cluster']]],
  ['huecos_34',['huecos',['../classProcesador.html#a4df6aff2b5cffc92889fa78a2665eec5',1,'Procesador']]]
];
