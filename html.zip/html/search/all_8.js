var searchData=
[
  ['no_5faceptados_54',['no_aceptados',['../classPrioridad.html#a6a03d42ec0812ea4e361222542a8541a',1,'Prioridad']]]
];
