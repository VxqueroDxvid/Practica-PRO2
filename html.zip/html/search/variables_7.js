var searchData=
[
  ['posiciones_144',['posiciones',['../classProcesador.html#ad37cb1c78bb33808f557ffdf35c2cdc6',1,'Procesador']]]
];
