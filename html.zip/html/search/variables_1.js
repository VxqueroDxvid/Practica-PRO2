var searchData=
[
  ['cant_5fmem_134',['cant_mem',['../classProceso.html#a0d23c7214afcc58bd50b67d1f450066d',1,'Proceso']]],
  ['capacidad_135',['capacidad',['../classProcesador.html#ad62f78b46bff1b9e04a1fae5bc7fa1e8',1,'Procesador']]]
];
