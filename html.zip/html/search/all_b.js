var searchData=
[
  ['tiempo_67',['tiempo',['../classProceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]],
  ['tiene_5fhijos_68',['tiene_hijos',['../classCluster.html#a97bc38af58dcfdc98c776340ef0c4fb1',1,'Cluster']]],
  ['tiene_5fproc_5fpendientes_69',['tiene_proc_pendientes',['../classArea__procesos.html#afcb2d4da98bb69108c2b43bb6f1c0c44',1,'Area_procesos::tiene_proc_pendientes()'],['../classPrioridad.html#aea09f00ca28ed01d40330a85d6bb38c3',1,'Prioridad::tiene_proc_pendientes()']]],
  ['tiene_5fprocesos_5fejec_70',['tiene_procesos_ejec',['../classCluster.html#ad6986dbbd177a71535cc8729923c7956',1,'Cluster::tiene_procesos_ejec()'],['../classProcesador.html#aada86683abb4def21dd0715dc456076a',1,'Procesador::tiene_procesos_ejec()']]]
];
