var searchData=
[
  ['a_132',['a',['../classCluster.html#a6ead59cf56e7df23edfc169f3cd70cb7',1,'Cluster']]],
  ['aceptados_133',['aceptados',['../classPrioridad.html#a618a5c55d8c8dcd68fa9e85dc0b26066',1,'Prioridad']]]
];
