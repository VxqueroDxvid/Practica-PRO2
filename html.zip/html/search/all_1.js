var searchData=
[
  ['baja_5fprioridad_9',['baja_prioridad',['../classArea__procesos.html#a528c3e438c9d5e81de0c351cd91d40b6',1,'Area_procesos']]],
  ['baja_5fproceso_10',['baja_proceso',['../classProcesador.html#aab22925eaa05343d930e70db16b16bee',1,'Procesador']]],
  ['baja_5fproceso_5fprocesador_11',['baja_proceso_procesador',['../classCluster.html#a35d4f86f4d7331c4f927247565e19f0c',1,'Cluster::baja_proceso_procesador()'],['../classProcesador.html#a29bd0bf95ebc0936fa055453becb93f8',1,'Procesador::baja_proceso_procesador()']]]
];
