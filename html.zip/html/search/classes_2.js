var searchData=
[
  ['prioridad_73',['Prioridad',['../classPrioridad.html',1,'']]],
  ['procesador_74',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_75',['Proceso',['../classProceso.html',1,'']]]
];
