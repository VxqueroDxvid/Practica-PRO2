var searchData=
[
  ['m_140',['m',['../classArea__procesos.html#a46e20406f11a32b22939e908839e61d0',1,'Area_procesos::m()'],['../classCluster.html#aabe94e5dcab8699611f3d1014fba8c71',1,'Cluster::m()']]],
  ['memlibre_141',['memlibre',['../classProcesador.html#aeb6a03bb5562c050ea01d2710e4a1456',1,'Procesador']]],
  ['memoria_142',['memoria',['../classProcesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador']]]
];
