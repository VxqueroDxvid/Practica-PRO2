var searchData=
[
  ['cabe_5fproceso_95',['cabe_proceso',['../classCluster.html#ad7dce71645c0c84c0b4d7615064895ae',1,'Cluster::cabe_proceso()'],['../classProcesador.html#ab0a8f3c0397ebab5f3fb9d84267ba476',1,'Procesador::cabe_proceso()']]],
  ['cabe_5fproceso_5farbol_96',['cabe_proceso_arbol',['../classCluster.html#aeb5b285b85abc4d1facdbcb294781f6c',1,'Cluster']]],
  ['cluster_97',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['compactar_5fmemoria_5fcluster_98',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_99',['compactar_memoria_procesador',['../classCluster.html#ae3385447255d8c6b441428350a16265c',1,'Cluster::compactar_memoria_procesador()'],['../classProcesador.html#a6c5d44f2b2e9aee6553a77d3056626f0',1,'Procesador::compactar_memoria_procesador()']]],
  ['configurar_5fcluster_100',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['consultar_5faceptados_101',['consultar_aceptados',['../classPrioridad.html#aa1a6f03689cd6b38d80463370f7acd9f',1,'Prioridad']]],
  ['consultar_5fcant_5fmem_102',['consultar_cant_mem',['../classProceso.html#abb14dd7d6a30fdd662c0c282f4b3697d',1,'Proceso']]],
  ['consultar_5fhueco_5fmin_103',['consultar_hueco_min',['../classProcesador.html#a1ac607e49dfa625f0e87530e29d29565',1,'Procesador']]],
  ['consultar_5fidproceso_104',['consultar_idproceso',['../classProceso.html#aff7b7091be3e669838f11da52ca55e22',1,'Proceso']]],
  ['consultar_5fmem_5flibre_105',['consultar_mem_libre',['../classProcesador.html#a30f00a22367b5a57b13fbbb2540603d0',1,'Procesador']]]
];
